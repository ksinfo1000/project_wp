jQuery(document).ready(function($) {

    $('#background_color').wpColorPicker();
    $('#odd_background_color').wpColorPicker();
    $ ('#category_background_color').wpColorPicker();

});
